"""
Package dynamos, implements functionality for handling Microservice chains in Python.

File: tracer.py

Description:
Simple generic tracer initiation.

Notes:
Some problems here.

Author: Jorrit Stutterheim
"""

from opentelemetry import trace
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
from opentelemetry.sdk.resources import SERVICE_NAME, Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.sdk.trace.sampling import ALWAYS_ON

import json
from opentelemetry.trace import SpanContext, TraceFlags, TraceState, NonRecordingSpan
from opentelemetry.trace.propagation import set_span_in_context

# Service name is required for most backends
# Service to initialize the tracer for a specific microservice.
def InitTracer(service_name : str, tracing_host : str):
    # Define the service-level resource (metadata for traces)
    resource = Resource(attributes={
        SERVICE_NAME: service_name
    })

    # Set up the TracerProvider with AlwaysOn sampling (matches Go's AlwaysSample)
    provider = TracerProvider(resource=resource, sampler=ALWAYS_ON)

    # Configure the OTLP gRPC exporter and batch processor
    processor = BatchSpanProcessor(
        OTLPSpanExporter(endpoint=tracing_host, insecure=True)
    )
    provider.add_span_processor(processor)

    # Register this provider as the global tracer provider
    trace.set_tracer_provider(provider)

    # Return a tracer scoped to this service
    return trace.get_tracer(f"{service_name}.tracer")

# Mirrors Go's StartRemoteParentSpan (see go/pkg/lib/tracing.go).
#
# Starts a new span using a remote parent span context, derived from binary data.
# This is used to maintain trace continuity across service boundaries.
#
# Parameters:
# - tracer: The OpenTelemetry tracer instance to use.
# - span_name: The name for the new span.
# - trace_map: A dictionary expected to contain a key "binaryTrace" with bytes.
#
# Returns:
# - ctx: A new context with the parent span set.
# - span: The newly started child span.
def start_remote_parent_span(tracer, span_name: str, trace_map: dict):
    # Use JSON trace format to avoid issues with binary data format from Go services (might have slightly different binary format)
    json_trace = trace_map.get("jsonTrace")
    # If no trace context was provided, start a new root span.
    if not json_trace:
        # No parent info, start a new root span
        span = tracer.start_span(span_name)
        ctx = set_span_in_context(span)
        return ctx, span

    # Attempt to extract the trace ID, span ID.
    try:
        trace_info = json.loads(json_trace.decode("utf-8") if isinstance(json_trace, bytes) else json_trace)
        trace_id = int(trace_info["TraceID"], 16)
        span_id = int(trace_info["SpanID"], 16)
    except Exception as e:
        raise ValueError(f"Invalid jsonTrace format: {e}")
    # Construct a remote SpanContext from the extracted fields.
    # Assume sampled by default (can be extended)
    span_context = SpanContext(
        trace_id=trace_id,
        span_id=span_id,
        is_remote=True,
        trace_state=TraceState()  # Empty state unless custom headers are used
    )

    # Wrap the remote context in a NonRecordingSpan and attach it to a new context.
    parent = NonRecordingSpan(span_context)
    ctx = set_span_in_context(parent)

    # Start a new span using the parent context.
    span = tracer.start_span(span_name, context=ctx)
    return ctx, span


def pretty_print_span_context(span):
    ctx = span.get_span_context()
    print(f"Trace ID: {format(ctx.trace_id, '032x')}")
    print(f"Span ID:   {format(ctx.span_id, '016x')}")
    print(f"Sampled:   {ctx.trace_flags.sampled}")
